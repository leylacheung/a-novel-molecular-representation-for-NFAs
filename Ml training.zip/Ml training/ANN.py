import numpy as np
import pandas as pd
from sklearn.model_selection import KFold
from sklearn.neural_network import MLPRegressor
from sklearn.metrics import mean_absolute_error, mean_squared_error, r2_score
from math import sqrt

# Load the dataset
df = pd.read_csv('data/Data_GCN.csv')

# Identify the maximum length of features after splitting
max_length = df['Features'].apply(lambda x: len(x.split(','))).max()

# Function to pad the features with zeros
def pad_features(feature_string, max_length):
    features = np.fromstring(feature_string, sep=',')
    padded_features = np.pad(features, (0, max_length - len(features)), 'constant', constant_values=0)
    return padded_features

# Apply padding to each row in the 'Features' column
X = np.array([pad_features(x, max_length) for x in df['Features']])
Y = df['HOMO(eV)'].values.reshape(-1, 1)  # Reshape Y to be a 2D array for scikit-learn

# Shuffle the data
np.random.seed(0)
indices = np.random.permutation(len(X))
X = X[indices]
Y = Y[indices]
kfold = 10

kf = KFold(n_splits=kfold, shuffle=True, random_state=0)

# Lists for storing metrics
mae_list = []
mse_list = []
rmse_list = []
mape_list = []
r2_list = []

for k, (train_idx, test_idx) in enumerate(kf.split(X, Y)):
    X_train, Y_train = X[train_idx], Y[train_idx]
    X_test, Y_test = X[test_idx], Y[test_idx]

    # Define the MLPRegressor model
    ann_model = MLPRegressor(hidden_layer_sizes=(100,), activation='relu', solver='adam', alpha=0.0001, batch_size='auto',
                             learning_rate='constant', learning_rate_init=0.001, power_t=0.5, max_iter=200, shuffle=True,
                             random_state=90, tol=0.0001, verbose=False, warm_start=False, momentum=0.9,
                             nesterovs_momentum=True, early_stopping=False, validation_fraction=0.1, beta_1=0.9,
                             beta_2=0.999, epsilon=1e-08, n_iter_no_change=10, max_fun=15000)

    # Train the model
    ann_model.fit(X_train, Y_train.ravel())

    # Predict on training data
    y_pred_train = ann_model.predict(X_train)

    # Training Metrics
    mae_train = mean_absolute_error(Y_train, y_pred_train)
    mse_train = mean_squared_error(Y_train, y_pred_train)
    rmse_train = sqrt(mse_train)
    mape_train = np.mean(np.abs((Y_train.ravel() - y_pred_train) / Y_train.ravel())) * 100
    r2_train = r2_score(Y_train, y_pred_train)

    # Predict on test data
    y_pred_test = ann_model.predict(X_test)

    # Test Metrics
    mae_test = mean_absolute_error(Y_test, y_pred_test)
    mse_test = mean_squared_error(Y_test, y_pred_test)
    rmse_test = sqrt(mse_test)
    mape_test = np.mean(np.abs((Y_test.ravel() - y_pred_test) / Y_test.ravel())) * 100
    r2_test = r2_score(Y_test, y_pred_test)

    # Append metrics to lists
    mae_list.append(mae_test)
    mse_list.append(mse_test)
    rmse_list.append(rmse_test)
    mape_list.append(mape_test)
    r2_list.append(r2_test)

    # Print metrics for each fold
    print(f"{k + 1} fold - Train Metrics | MAE: {mae_train}, MSE: {mse_train}, RMSE: {rmse_train}, MAPE: {mape_train}, R^2: {r2_train}")
    print(f"{k + 1} fold - Test Metrics | MAE: {mae_test}, MSE: {mse_test}, RMSE: {rmse_test}, MAPE: {mape_test}, R^2: {r2_test}")

# Calculate and print average metrics
print("Average Train Metrics - MAE: {:.3f}, MSE: {:.3f}, RMSE: {:.3f}, MAPE: {:.3f}%, R^2: {:.3f}".format(
    np.mean(mae_list), np.mean(mse_list), np.mean(rmse_list), np.mean(mape_list), np.mean(r2_list)))
print("Average Test Metrics - MAE: {:.3f}, MSE: {:.3f}, RMSE: {:.3f}, MAPE: {:.3f}%, R^2: {:.3f}".format(
    np.mean(mae_list), np.mean(mse_list), np.mean(rmse_list), np.mean(mape_list), np.mean(r2_list)))